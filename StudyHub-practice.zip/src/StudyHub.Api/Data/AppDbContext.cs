using Microsoft.EntityFrameworkCore;
using StudyHub.Api.Domain;

namespace StudyHub.Api.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Material> Materials => Set<Material>();
    public DbSet<Tag> Tags => Set<Tag>();
    public DbSet<Report> Reports => Set<Report>();
    public DbSet<HelpfulVote> HelpfulVotes => Set<HelpfulVote>();
    public DbSet<Comment> Comments => Set<Comment>();
    public DbSet<Quiz> Quizzes => Set<Quiz>();
    public DbSet<QuizQuestion> QuizQuestions => Set<QuizQuestion>();
    public DbSet<GameSession> GameSessions => Set<GameSession>();
    public DbSet<GameResult> GameResults => Set<GameResult>();
    public DbSet<GameQuestionStat> GameQuestionStats => Set<GameQuestionStat>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>(e =>
        {
            e.Property(u => u.Email).HasMaxLength(256);
            e.Property(u => u.DisplayName).HasMaxLength(100);
            e.HasIndex(u => u.Email).IsUnique();
        });

        modelBuilder.Entity<Material>(e =>
        {
            e.Property(m => m.Title).HasMaxLength(200);
            e.Property(m => m.CourseCode).HasMaxLength(20);
            e.HasIndex(m => m.CreatedAtUtc);

            e.HasOne(m => m.Author)
                .WithMany(u => u.Materials)
                .HasForeignKey(m => m.AuthorId)
                .OnDelete(DeleteBehavior.Cascade);

            // Many-to-many: EF Core creates the join table for us.
            e.HasMany(m => m.Tags).WithMany(t => t.Materials);
        });

        modelBuilder.Entity<Tag>(e =>
        {
            e.Property(t => t.Name).HasMaxLength(50);
            e.HasIndex(t => t.Name).IsUnique();
        });

        modelBuilder.Entity<Report>(e =>
        {
            e.Property(r => r.Reason).HasMaxLength(500);

            e.HasOne(r => r.Material)
                .WithMany(m => m.Reports)
                .HasForeignKey(r => r.MaterialId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne<User>()
                .WithMany()
                .HasForeignKey(r => r.ReporterId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<HelpfulVote>(e =>
        {
            // The key is the pair (note, student), so the database itself
            // stops one student voting twice on the same note.
            e.HasKey(v => new { v.MaterialId, v.UserId });

            e.HasOne(v => v.Material)
                .WithMany(m => m.HelpfulVotes)
                .HasForeignKey(v => v.MaterialId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne<User>()
                .WithMany()
                .HasForeignKey(v => v.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Comment>(e =>
        {
            e.Property(c => c.Body).HasMaxLength(1000);

            // Comments are always read per note, oldest first.
            e.HasIndex(c => new { c.MaterialId, c.CreatedAtUtc });

            e.HasOne(c => c.Material)
                .WithMany(m => m.Comments)
                .HasForeignKey(c => c.MaterialId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(c => c.Author)
                .WithMany()
                .HasForeignKey(c => c.AuthorId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Quiz>(e =>
        {
            e.Property(q => q.Title).HasMaxLength(200);
            e.Property(q => q.Topic).HasMaxLength(50);
            e.HasIndex(q => new { q.OwnerId, q.CreatedAtUtc });
            e.HasIndex(q => new { q.IsPublic, q.Topic });

            e.HasOne(q => q.Owner)
                .WithMany()
                .HasForeignKey(q => q.OwnerId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<QuizQuestion>(e =>
        {
            e.Property(q => q.Text).HasMaxLength(500);
            e.Property(q => q.OptionA).HasMaxLength(200);
            e.Property(q => q.OptionB).HasMaxLength(200);
            e.Property(q => q.OptionC).HasMaxLength(200);
            e.Property(q => q.OptionD).HasMaxLength(200);

            e.HasOne(q => q.Quiz)
                .WithMany(quiz => quiz.Questions)
                .HasForeignKey(q => q.QuizId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<GameSession>(e =>
        {
            e.Property(s => s.QuizTitle).HasMaxLength(200);
            e.HasIndex(s => new { s.QuizId, s.PlayedAtUtc });
            e.HasIndex(s => s.PlayedAtUtc);

            // Deleting a quiz keeps its past games, so players don't lose their history.
            e.HasOne(s => s.Quiz)
                .WithMany()
                .HasForeignKey(s => s.QuizId)
                .OnDelete(DeleteBehavior.SetNull);

            e.HasOne<User>()
                .WithMany()
                .HasForeignKey(s => s.HostId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<GameResult>(e =>
        {
            e.Property(r => r.Nickname).HasMaxLength(50);
            e.HasIndex(r => r.UserId);

            e.HasOne(r => r.Session)
                .WithMany(s => s.Results)
                .HasForeignKey(r => r.SessionId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne<User>()
                .WithMany()
                .HasForeignKey(r => r.UserId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<GameQuestionStat>(e =>
        {
            e.Property(q => q.QuestionText).HasMaxLength(500);

            e.HasOne(q => q.Session)
                .WithMany(s => s.QuestionStats)
                .HasForeignKey(q => q.SessionId)
                .OnDelete(DeleteBehavior.Cascade);
        });
    }
}
